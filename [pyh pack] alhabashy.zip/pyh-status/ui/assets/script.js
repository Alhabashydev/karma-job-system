
document.addEventListener("DOMContentLoaded", function() {
    var mainElement = document.getElementById("main");
    var titleElement = document.getElementById("title");
    var contentsElement = document.getElementById("contents");

    // Check if all necessary elements are found before proceeding
    if (mainElement && titleElement && contentsElement) {
        mainElement.style.display = "none";

        // Event listener for messages
        window.addEventListener("message", function(event) {
            if (event.data.action === "open") {
                mainElement.style.display = "block";

                titleElement.innerHTML = event.data.title;

                let values = event.data.values;
                if (values.length > 0) {
                    contentsElement.style.display = "block";
                    var c = "";
                    var i = null;
                    var s = null;
                    var hasTimer = false;
                    values.forEach((item, index) => {
                        if (typeof item === "string") {
                            c += `<p>${item}</p>`;
                        } else if (item.type === "countdown") {
                            // Assuming item.seconds is the duration for the countdown
                            c += `<p>Time Left <span id="countdown-${index}"></span></p>`;
                            s = item.seconds;
                            i = index;
                            hasTimer = true;
                            // Start the countdown
                        }
                    });
                    contentsElement.innerHTML = c;
                    if (hasTimer) { startCountdown(s, `countdown-${i}`); }             
                } else {
                    contentsElement.style.display = "none";
                }

                

                // Use jQuery to animate the main element (assuming jQuery is loaded)
                
            } else if (event.data.action === "close") {
                // Use jQuery to animate the main element (assuming jQuery is loaded)

                setTimeout(function() {
                    mainElement.style.display = "none";
                    contentsElement.innerHTML = "";
                    titleElement.innerHTML = "";
                }, 1000);
            }
        });
    } else {
        console.error("One or more required elements not found.");
    }
});

// Function to start the countdown
function startCountdown(seconds, elementId) {
    var countdownElement = document.getElementById(elementId);
    var intervalId = setInterval(function() {
        countdownElement.innerText = formatTime(seconds);
        seconds--;
        if (seconds < 0) {
            clearInterval(intervalId);
        }
    }, 1000);
}

// Function to format time in mm:ss format
function formatTime(seconds) {
    var minutes = Math.floor(seconds / 60);
    var remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
}