# pyh Developments - Interaction System 4.0 - by Forlax

- Hello, first of all thank you to use our script !
- Feel free to open a support Ticket to resolve your problem/question. - pyh Developments -


# How to use exports:
  
  exports["pyh-interaction"]:showInteraction('KEY', 'TEXT')

- Also, u can make an export, without the key like this:

  exports["pyh-interaction"]:showInteraction('', 'TEXT')

- or

  exports["pyh-interaction"]:showInteraction(nil, 'TEXT')

- Hiding interaction:
  
  exports["pyh-interaction"]:hideInteraction()

# Preview

![image](https://i.imgur.com/iIKdZJM.png)

# Discord: forlax_pyh
# pyh Developments Discord: https://discord.gg/vA6mQNrXKS
