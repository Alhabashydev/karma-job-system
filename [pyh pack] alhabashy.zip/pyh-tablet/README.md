# pyh Developments - Tablet System - by Forlax

- Hello, first of all thank you for purchasing our script !

- Feel free to open a support ticket to resolve your problem/question. - pyh Developments - 

- Items to be added to QBCore `qb-core/shared/items.lua` :


````lua

tablet = { name = 'Pixel Tablet', label = 'Old Still', weight = 500, type = 'item', image = 'tablet.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = "Tablet" },

hqchip = { name = 'hqchip', label = 'HQ Chip', weight = 500, type = 'item', image = 'hqchip.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = "Chip for the Pixel Tablet" },

ugchip = { name = 'ugchip', label = 'Underground Chip', weight = 500, type = 'item', image = 'ugchip.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = "Chip for the Pixel Tablet" },

````

# Discord: Forlax
# pyh Discord Discord : https://discord.gg/vA6mQNrXKS
# Copyright (c) 2023-2024, pyh Developments Ltd. All rights reserved.