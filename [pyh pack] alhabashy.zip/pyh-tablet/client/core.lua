--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


if Config.Framework == 'QBCore' then
    pyh = exports[Config.FrameworkFolder]:GetCoreObject()
else
    pyh = exports[Config.FrameworkFolder]:getSharedObject()
end

function Notify(msg, typ)
    if Config.Framework == 'QBCore' then
        pyh.Functions.Notify(msg, typ)
    else
        pyh.ShowHelpNotification(msg)
    end
end

function TriggerCallback(name, cb, ...)
    if Config.Framework == 'QBCore' then
        pyh.Functions.TriggerCallback(name, cb, ...)
    else
        pyh.TriggerServerCallback(name, cb, ...)
    end
end

function ProgBar(name, label, duration, disableOptions, animOptions, onFinish, onCancel)
    if Config.Framework == 'QBCore' then
        pyh.Functions.Progressbar(name, label, duration, false, true, disableOptions, animOptions, {}, {}, onFinish, onCancel)
    else
        exports["esx_progressbar"]:Progressbar(name, duration, {
            FreezePlayer = disableOptions.disableMovement,
            animation = {
                type = "anim",
                dict = animOptions.animDict,
                lib = animOptions.anim
            },
            onFinish = onFinish,
            onCancel = onCancel
        })
    end
end--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


