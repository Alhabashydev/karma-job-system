


Config = {}

Config.Framework = 'QBCore' -- QBCore or ESX or Custom

Config.FrameworkFolder = 'qb-core' -- 'qb-core' or 'ex_extended' or 'yourframeworkfolder'

Config.Inventory = 'OX' -- qb-inventory / OX--
