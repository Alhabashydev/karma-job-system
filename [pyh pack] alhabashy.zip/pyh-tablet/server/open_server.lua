--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


if Config.Framework == 'QBCore' then 
    QBCore = exports[Config.FrameworkFolder]:GetCoreObject()

    QBCore.Functions.CreateUseableItem("tablet", function(source)
        TriggerClientEvent("pyh-tablet:openTablet", source)
    end)

elseif Config.Framewework == 'ESX' then 
    ESX = exports[Config.FrameworkFolder]:getSharedObject()

    ESX.RegisterUsableItem('tablet', function(source)
        TriggerClientEvent('pyh-tablet:openTablet', source)
    end)
    
elseif Config.Framework == 'Custom' then
    -- Put here your variables and your own Code.
end



RegisterCallback('pyh-tablet:hasItem', function(source, cb, item)
    local player = GetPlayer(source)
    if player then
        local hasItem = GetItembyName(item, player)  
        cb(hasItem)
    else
        cb(false)
    end
end)

--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


