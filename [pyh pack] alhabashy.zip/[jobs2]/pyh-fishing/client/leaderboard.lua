--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


RegisterNetEvent("pyh-fishing:showLeaderboard", function(data, cb)

    local fishNames = {}
    for _, fish in ipairs(Config.fishLists) do
        table.insert(fishNames, fish.name)
    end

    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "showLeaderboard",
        fishList = fishNames
    })
    --[[ cb("ok") ]]
end)


RegisterNUICallback("hideMenu", function(data, cb)

    SetNuiFocus(false, false)

end)

RegisterNUICallback("fetchLeaderboard", function(data, cb)
    local fishName = data.fishName

    TriggerCallback("pyh-fishing:server:getLeaderboard", function(result)
        if result then
            SendNUIMessage({
                type = "updateLeaderboard",
                leaderboard = result
            })
        else
            SendNUIMessage({
                type = "updateLeaderboard",
                leaderboard = {}
            })
        end
    end, fishName)
end)

--[[ RegisterCommand("openLeaderboard", function()
    TriggerEvent("pyh-fishing:showLeaderboard")
end) ]]--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


