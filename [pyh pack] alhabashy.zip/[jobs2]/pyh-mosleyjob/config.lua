--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


Config = {
    Framework = 'QBCore', -- QBCore or ESX
    FrameworkFolder = 'qb-core', -- qb-core or es_extended
    Inventory = 'qb-inventory', -- qb-inventory & ox_inventory  
    payment = math.random(400, 650),
    cooldown = 120000,
    gainRep = 1,
    mozCoords = vector4(-10.5716, -1665.9514, 27.9234, 309.2401),
    MosleyInteriorZone = {
        vector2(-25.481876373291, -1668.0914306641),
        vector2(-10.578371047974, -1680.1715087891),
        vector2(1.4855766296387, -1674.966796875),
        vector2(4.6547002792358, -1670.9156494141),
        vector2(-15.633688926697, -1654.1502685547),
    },

    jobs = {
        {
            ped = vector4(1037.5034, -765.2757, 56.9686, 239.0061),
            veh = vector4(1040.0685, -769.4899, 58.0171, 351.2418)
        },
        {
            ped = vector4(-957.9120, -2709.9712, 12.8310, 58.6852),
            veh = vector4(-960.5792, -2709.3030, 13.8310, 11.8397)
        },
        {
            ped = vector4(-519.4963, 46.9933, 51.5799, 42.6388),
            veh = vector4(-521.4611, 49.1252, 52.5799, 87.9913)
        },     
        -- Add more ;)
    },

    jobVehicles = {
        "sentinel",
        "baller",
        "t20",
        "ingot",
        "blista2",
        "buffalo4",
        "WASHINGTON",
        "club",
        "TAILGATER2",
        "RHINEHART",
        "RAPIDGT",
        "RAIDEN"
        -- Add more ;)
    },

    UpgradeCategories = {
        headlights = {
            options = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
            item = "headlights"
        },
        livery = {
            options = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
            item = "livery"
        },
        neon = {
            options = {
                { r = 255, g = 0, b = 0 },
                { r = 0, g = 255, b = 0 },
                { r = 0, g = 0, b = 255 },
                { r = 255, g = 255, b = 0 },
                { r = 255, g = 0, b = 255 },
                { r = 0, g = 255, b = 255 },
                { r = 255, g = 255, b = 255 }
            },
            item = "neon"
        },
        color = {
            options = {
                primary = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                secondary = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                pearlescent = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                wheel = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
            },
            item = "color"
        },
        plateColor = {
            options = {0, 1, 2, 3, 4, 5},
            item = "platecolor"
        },
        horn = {
            options = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
            item = "horns"
        }
    },


}--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


