# NPC Dialog

```
{
    name = "Max Mosley's",
    private = false, 
    text = "Hey there, I don't think we've crossed paths before. I'm Max, and I'm in charge of the Mosley's. You thinkin' about joining our crew?", 
    domain = "Mosley's", 
    ped = "s_m_m_autoshop_01", 
    scenario = "WORLD_HUMAN_CLIPBOARD", 
    police = true, 
    coords = vector4(-37.6105, -1677.4086, 28.4917, 142.1383), 
    options = { 
        {
            label = "I want to work",
            requiredrep = 0, 
            type = "add",
            event = "",
            data = {
                text = "Ready for a day of hard work?",
                options = {
                    {
                        label = "Mosleys (In/Out)", 
                        event = "pyh-mosleyjob:cl:init", 
                        type = "client",
                        args = {}
                    },
                    {
                        label = "Leave conversation",  --To be added later
                        event = "", 
                        type = "none",
                        args = {}
                    },
                }
            },
            args = {} 
        },
        {
			label = "Leave conversation",
			event = "", 
			type = "none",
			args = {}
		},
    }
}, 
```


# Items

```

headlights = { name = 'headlights', label = 'Headlights Upgrade', weight = 1000, type = 'item', image = 'part.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = 'Upgrade your vehicle\'s headlights.' },
livery = { name = 'livery', label = 'Livery Upgrade', weight = 1000, type = 'item', image = 'part.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = 'Change your vehicle\'s livery.' },
neon = { name = 'neon', label = 'Neon Lights Upgrade', weight = 1000, type = 'item', image = 'part.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = 'Install neon lights on your vehicle.' },
color = { name = 'color', label = 'Color Upgrade', weight = 1000, type = 'item', image = 'part.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = 'Change the color of your vehicle.' },
platecolor = { name = 'platecolor', label = 'Plate Color Upgrade', weight = 1000, type = 'item', image = 'part.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = 'Change the color of your vehicle\'s plate.' },
horns = { name = 'horns', label = 'Horn Upgrade', weight = 1000, type = 'item', image = 'part.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = 'Upgrade your vehicle\'s horn.' },

```