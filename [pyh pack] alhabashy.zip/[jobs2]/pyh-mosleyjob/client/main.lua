--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


local currentJobStage = "WAITING"
local GroupID = 0 -- make this 0 later if I forget! 
local isGroupLeader = false

local cooldown = false

local missionVehNetId = nil
local hasJob = false
local tookVeh = false
local vehDel = nil

local selectedUpgrades = {}

local installedUpgrades = 0
local totalUpgrades = 0
local jobPedId = nil
local blip = nil
local uName = nil


local polyzones = {}
local createdNPCs = {}


function removePolyZone(zone)
    for i, polyzone in ipairs(polyzones) do
        if polyzone == zone then
            table.remove(polyzones, i)
            break
        end
    end
end

RegisterNetEvent("pyh-mosleyjob:cl:init", function()
    if GroupID == 0 then
        Notify("Make or join a group first!", "error")
        return
    end

    if hasJob then
        Notify("You are already on a job?", "error")
        return
    end

    if cooldown then
        Notify("Comeback later for more work.", "error")
        return
    end

    local mozlyZone = PolyZone:Create(Config.MosleyInteriorZone, {
        name="mosleys_interior",
        minZ=26,
        maxZ=32.71283531189,
        debugGrid=false,
    })

    mozlyZone:onPlayerInOut(function(inside)
        Wait(500)
        if inside and hasJob and tookVeh then
            TriggerServerEvent("pyh-mosleyjob:sv:giveUpgradeItems", GroupID)
            mozlyZone:destroy()
            removePolyZone(mozlyZone)
        end
    end)
    
    table.insert(polyzones, mozlyZone)
    TriggerServerEvent("pyh-mosleyjob:sv:initt", GroupID)
end)


RegisterNetEvent("pyh-mosleyjob:cl:startJob", function(vehModel, pedPos, vehPos, offerWait)
    hasJob = true
    tookVeh = false
    missionVehNetId = nil
    installedUpgrades = 0
    totalUpgrades = 0
    blip = nil
    vehDel = vehPos

    exports["pyh-status"]:Show("Waiting for job offer", {})

    local pedModel = 'a_f_y_hipster_01'
    RequestModel(GetHashKey(pedModel))
    while not HasModelLoaded(GetHashKey(pedModel)) do
        Wait(500)
    end

    Citizen.Wait(offerWait)

    local npcPed = CreatePed(4, GetHashKey(pedModel), pedPos.x, pedPos.y, pedPos.z, pedPos.w, false, false)
    FreezeEntityPosition(npcPed, true)
    SetEntityInvincible(npcPed, true)
    SetBlockingOfNonTemporaryEvents(npcPed, true)
    

    if DoesEntityExist(npcPed) then
        jobPedId = npcPed


        FreezeEntityPosition(npcPed, true)
        SetEntityInvincible(npcPed, true)
        SetBlockingOfNonTemporaryEvents(npcPed, true)

        table.insert(createdNPCs, npcPed)
        
        
        
        local interactId = tostring(math.random(11, 99))
        
        exports.interact:AddLocalEntityInteraction({
            entity = npcPed,
            name = name, 
            id = interactId..math.random(100, 999),
            distance = 6.0, 
            interactDst = 4.0, 
            ignoreLos = true, 
            options = {
                {
                    label = "Take Vehicle",
                    action = function(entity, coords, args)
                        if IsAnyVehicleNearPoint(vehPos.x, vehPos.y, vehPos.z, 2.0) then
                            Notify("Spawn spot is occupied!")
                            return
                        end

                        if Config.Framework == 'QBCore' then
                            pyh.Functions.SpawnVehicle(vehModel, function(veh)  
                                SetEntityHeading(veh, vehPos.w)
                                SetVehicleEngineOn(veh, false, false)
                                SetVehicleOnGroundProperly(veh)
                                SetVehicleNeedsToBeHotwired(veh, false)
                                    
                                TriggerEvent("vehiclekeys:client:SetOwner", GetVehicleNumberPlateText(veh))
                                SetVehicleDoorsLocked(veh, 1)
                    
                                local netId = NetworkGetNetworkIdFromEntity(veh)
                                
                                TriggerServerEvent("pyh-mosleyjob:sv:assignDV", netId, GroupID, interactId)

                            end, vehPos, true)
                        else
                            pyh.Game.SpawnVehicle(vehModel, vehPos, vehPos.w, function(veh)
                                SetEntityHeading(veh, vehPos.w)
                                SetVehicleEngineOn(veh, false, false)
                                SetVehicleOnGroundProperly(veh)
                                SetVehicleNeedsToBeHotwired(veh, false)          
                    
                                TriggerEvent("keys:received", GetVehicleNumberPlateText(veh))
                                SetVehicleDoorsLocked(veh,1)
                    
                                local netId = NetworkGetNetworkIdFromEntity(veh)
                                
                                TriggerServerEvent("pyh-mosleyjob:sv:assignDV", netId, GroupID, interactId)
                                
                            end)
                        end
                    end,
                },
            }
        })


        blip = AddBlipForCoord(pedPos)
        SetBlipSprite(blip, 47) 
        SetBlipDisplay(blip, 2)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, 5)
        SetBlipRoute(blip, true)

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName("Mosley Pickup")
        EndTextCommandSetBlipName(blip)

        --SetNewWaypoint(pedPos.x, pedPos.y)
        exports["pyh-status"]:Show("Mosley's Job", {"Go to the customer"})



    end
end)
 --Engine
    --offset = vec3(0.0, 0.0, 0.0),
    --bone = 'engine',

    --Front
    --offset = vec3(0.0, 1.0, 0.0),
    --bone = 'engine',

    --Window Left 1
    --offset = vec3(-0.8, 0.0, 0.0),

    --Window Right 1
    -- offset = vec3(0.8, 0.0, 0.0),

    --Window Left 1
    --offset = vec3(-0.8, -1, 0.0),

    --Window Right 1
    -- offset = vec3(0.8, -1, 0.0),


    --Trunk
    --offset = vec3(0.0, 0.0, 0.0),
    --bone = 'boot',

local installedSoFar = 0
local tInstalled = 0
local interCIId = 0

local function upgrady()
    local shouldICall = false
    local vehicle = NetworkGetEntityFromNetworkId(missionVehNetId)
                
    ProgBar("upgradeinstall", "Installing Upgrade", math.random(5, 10) * 1000, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
            animDict = "anim@amb@clubhouse@tutorial@bkr_tut_ig3@",
            anim = "machinic_loop_mechandplayer",
            flags = 49,
        }, function() -- Done
        
        local itemName = uName

        if interCIId == 10 then
            exports.interact:RemoveEntityInteraction(missionVehNetId, "vehUpg"..interCIId)
        else
            exports.interact:RemoveEntityInteraction(missionVehNetId, "vehUpg"..(installedSoFar +1))
        end

        

        local upgrade = selectedUpgrades[itemName]

        if itemName == 'headlights' then
            if upgrade.value then
                SetVehicleHeadlightsColour(vehicle, upgrade.value)
                installedSoFar = installedSoFar + 1
                
                if installedSoFar >= tInstalled then
                    shouldICall = true
                end

            end
        elseif itemName == 'livery' then
            if upgrade.value then
                SetVehicleLivery(vehicle, upgrade.value)
                shouldICall = true
            end
        elseif itemName == 'neon' then
            local color = upgrade.color
            if color then
                SetVehicleNeonLightsColour(vehicle, color.r, color.g, color.b)          
                if upgrade.left or upgrade.right or upgrade.front or upgrade.back then
                    if upgrade.left then 
                        SetVehicleNeonLightEnabled(vehicle, 0, true) 
                    end
                    if upgrade.right then 
                        SetVehicleNeonLightEnabled(vehicle, 1, true) 
                    end
                    if upgrade.front then 
                        SetVehicleNeonLightEnabled(vehicle, 2, true) 
                    end
                    if upgrade.back then 
                        SetVehicleNeonLightEnabled(vehicle, 3, true) 
                    end

                    shouldICall = true
                end
            end
        elseif itemName == 'color' then
            local colorOptions = upgrade
            if colorOptions.primary and colorOptions.secondary then
                SetVehicleColours(vehicle, colorOptions.primary, colorOptions.secondary)
            end
            if colorOptions.pearlescent and colorOptions.wheel then
                SetVehicleExtraColours(vehicle, colorOptions.pearlescent, colorOptions.wheel)
            end
            shouldICall = true
        elseif itemName == 'platecolor' then
            SetVehicleNumberPlateTextIndex(vehicle, math.random(0, 4))
            shouldICall = true
        elseif itemName == 'horns' then
            SetVehicleModKit(vehicle, 0)
            local hornMods = {1,2,3,4,5,6,7,8,9}
            local randomIndex = math.random(#hornMods)
            local newHornMod = hornMods[randomIndex]
            SetVehicleMod(vehicle, 14, newHornMod)
            StartVehicleHorn(vehicle, 2000, "HELDDOWN", false)  
            shouldICall = true 
        end

        if shouldICall then
            installedUpgrades = installedUpgrades + 1
            TriggerServerEvent("pyh-mosleyjob:sv:updateStatus", GroupID, installedUpgrades, totalUpgrades, itemName)
        end

        Notify("Upgraded "..itemName.." on the vehicle!", "success")
        
    end, function()
        
    end) 

end


RegisterNetEvent('pyh-mosleyjob:upgradeVehicle')
AddEventHandler('pyh-mosleyjob:upgradeVehicle', function(itemName)
    uName = itemName

    local vehicle = NetworkGetEntityFromNetworkId(missionVehNetId)
    local ped = PlayerPedId()
    if not DoesEntityExist(vehicle) or not hasJob or IsPedInAnyVehicle(ped, false) then
        return
    end

    local playerPos = GetEntityCoords(ped)
    local vehiclePos = GetEntityCoords(vehicle)

    local distance = #(playerPos - vehiclePos)
    
    if distance > 5.0 then
        Notify("You're too far from the vehicle.", "error")
        return
    end

    --Window Left 1
    --offset = vec3(-0.8, 0.0, 0.0),

    --Window Right 1
    -- offset = vec3(0.8, 0.0, 0.0),

    --Window Left 1
    --offset = vec3(-0.8, -1, 0.0),

    --Window Right 1
    -- offset = vec3(0.8, -1, 0.0),

    local oo = nil
    if uName == "headlights" then
        installedSoFar = 0
        tInstalled = 0
        for i = 1, 2 do
            
            tInstalled = 2
            if i == 1 then
                oo = vec3(-0.8, 0.0, 0.0)
            elseif i == 2 then
                oo = vec3(0.8, 0.0, 0.0)
            end

            interCIId = i

            exports.interact:AddEntityInteraction({
                netId = missionVehNetId,
                id = 'vehUpg'..i, 
                offset = oo,
                distance = 6.0,
                interactDst = 3.0,
                ignoreLos = true,
                options = {
                    {
                        label = "Install "..itemName,
                        action = function(entity, coords, args)
                            upgrady()
                        end,
                    },
                }
            })  
        end
    elseif uName == "horns" then
        interCIId = 10
        exports.interact:AddEntityInteraction({
            netId = missionVehNetId,
            id = 'vehUpg'..interCIId, 
            distance = 6.0,
            offset = vec3(0.0, 0.0, 0.0),
            bone = 'engine',
            interactDst = 3.0,
            ignoreLos = true,
            options = {
                {
                    label = "Install "..itemName,
                    action = function(entity, coords, args)
                        upgrady()
                    end,
                },
            }
        })  
    elseif uName == "platecolor" then
        interCIId = 10
        exports.interact:AddEntityInteraction({
            netId = missionVehNetId,
            id = 'vehUpg'..interCIId, 
            distance = 6.0,
            offset = vec3(0.0, 0.0, 0.0),
            bone = 'exhaust',
            interactDst = 3.0,
            ignoreLos = true,
            options = {
                {
                    label = "Install "..itemName,
                    action = function(entity, coords, args)
                        upgrady()
                    end,
                },
            }
        })  
    else
        interCIId = 10
        exports.interact:AddEntityInteraction({
            netId = missionVehNetId,
            id = 'vehUpg'..interCIId, 
            distance = 6.0,
            interactDst = 3.0,
            ignoreLos = true,
            options = {
                {
                    label = "Install "..itemName,
                    action = function(entity, coords, args)
                        upgrady()
                    end,
                },
            }
        })  
    end
    

    
end)



RegisterNetEvent("pyh-mosleyjob:cl:updateStatus", function(i, t) 
    if i then
        installedUpgrades = i
    end
    
    if t and t > 0 then
        totalUpgrades = t
    end

    exports["pyh-status"]:Show("Mosley's Job", {"Install Parts "..installedUpgrades.."/"..totalUpgrades})
end)

RegisterNetEvent("pyh-mosleyjob:cl:getUpgrades", function(u)  
    selectedUpgrades = u
end)

RegisterNetEvent("pyh-mosleyjob:cl:returnVeh", function()
    if DoesBlipExist(blip) then
        RemoveBlip(blip)
    end
    
    installedUpgrades = installedUpgrades + 1
    SetNewWaypoint(vehDel.x, vehDel.y)
    exports["pyh-status"]:Show("Mosley's Job", {"Return the vehicle to its owner."})

    Citizen.CreateThread(function()
        local isWithinLoop = true
        while isWithinLoop do
            Citizen.Wait(5000)

            local vehicle = NetworkGetEntityFromNetworkId(missionVehNetId)

            if vehicle then
                local vehicleCoords = GetEntityCoords(vehicle)
                local distance = GetDistanceBetweenCoords(vehicleCoords, vehDel, true)

                if distance < 8.0 then
                    TriggerServerEvent("pyh-mosleyjob:sv:bridge", GroupID)
                    TaskLeaveVehicle(PlayerPedId(), vehicle, 0)
                    
                    Citizen.CreateThread(function()
                        local vehicleLeft = false
                        while not vehicleLeft do
                            Citizen.Wait(1000)
                            if not IsPedInVehicle(PlayerPedId(), vehicle, true) then
                                vehicleLeft = true

                                NetworkFadeOutEntity(vehicle, true, true)
                                Citizen.Wait(1000)
                                SetEntityAsMissionEntity(vehicle, true, true)
                                Citizen.Wait(1100)
                                DeleteEntity(vehicle)

                                isWithinLoop = false
                            end
                        end
                    end)
                end
            end
        end
    end)
end)


RegisterNetEvent("pyh-mosleyjob:cl:bridge", function()  
    exports.interact:RemoveInteraction('mosDelVeh')
    
    cooldown = true
    hasJob = false

    Citizen.CreateThread(function()
        Citizen.Wait(Config.cooldown)
        cooldown = false
    end)

    exports["pyh-status"]:Close()
    TriggerServerEvent("pyh-mosleyjob:sv:antibich", GroupID)
end)

RegisterNetEvent("pyh-mosleyjob:cl:assignDV", function(netId, interactId)
    exports.interact:RemoveInteraction(interactId)
    
    local stupidPed = jobPedId
    if DoesEntityExist(stupidPed) then
        DeleteEntity(stupidPed)
    end

    if DoesBlipExist(blip) then
        RemoveBlip(blip)
    end

    blip = AddBlipForCoord(Config.mozCoords)

    SetBlipSprite(blip, 225) 
    SetBlipDisplay(blip, 2)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, 5)
    SetBlipRoute(blip, true)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentSubstringPlayerName("Mosley Pickup")
    EndTextCommandSetBlipName(blip)

    local veh = NetworkGetEntityFromNetworkId(netId)
    if veh and GetVehicleNumberPlateText(veh) then          
        missionVehNetId = netId
        tookVeh = true
        exports["pyh-status"]:Show("Mosley's Job", {"Go back to Mosley's"})
    else
        print("shit went wrong with network again")
    end
end)

RegisterNetEvent("pyh-mosleyjob:clear", function()  

    missionVehNetId = nil
    hasJob = false
    tookVeh = false
    vehDel = nil
    selectedUpgrades = {}
    installedUpgrades = 0
    totalUpgrades = 0
    jobPedId = nil
    blip = nil
end)



--[[ 

RegisterCommand('mosly', function()
    TriggerEvent("pyh-mosleyjob:cl:init")
end, false)

AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() == resourceName then
  
    end
end) ]]

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        if polyzones then
            for i, zone in ipairs(polyzones) do
                zone:destroy()
            end
            polyzones = {}
        end

        if createdNPCs then
            for _, npcPed in ipairs(createdNPCs) do
                if DoesEntityExist(npcPed) then
                    DeletePed(npcPed)
                end
            end
            createdNPCs = {}
        end

        if DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
    end
end)

RegisterNetEvent("groups:updateJobStage", function(stage)
    currentJobStage = stage
end)

RegisterNetEvent("groups:JoinGroup", function(id)
    GroupID = id
end)

RegisterNetEvent("groups:UpdateLeader", function()
    isGroupLeader = true
end)

RegisterNetEvent("groups:GroupDestroy", function()
    currentJobStage = "WAITING"
    GroupID = 0
    isGroupLeader = false
end)--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


