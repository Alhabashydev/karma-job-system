--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


function getRandomUpgrades()
    local selectedUpgrades = {}
    local categories = {}
    local availableCategories = {}
    local availableOptions = {}

    for category, data in pairs(Config.UpgradeCategories) do
        table.insert(categories, category)
        availableCategories[category] = data.options
        availableOptions[category] = data.item
    end

    for i = #categories, 2, -1 do
        local j = math.random(1, i)
        categories[i], categories[j] = categories[j], categories[i]
    end

    local numUpgrades = math.random(4, 6)
    local pickedCategories = {}

    for i = 1, numUpgrades do
        if #categories == 0 then break end

        local category = table.remove(categories, math.random(#categories))
        table.insert(pickedCategories, category)

        if availableCategories[category] then
            local options = availableCategories[category]
            local item = availableOptions[category]

            if category == "neon" then

                selectedUpgrades[category] = {
                    left = true,
                    right = true,
                    front = true,
                    back = true,
                    color = options[math.random(#options)]
                }
            elseif category == "color" then
                local colorOptions = {
                    primary = options.primary and options.primary[math.random(#options.primary)],
                    secondary = options.secondary and options.secondary[math.random(#options.secondary)],
                    pearlescent = options.pearlescent and options.pearlescent[math.random(#options.pearlescent)],
                    wheel = options.wheel and options.wheel[math.random(#options.wheel)]
                }
                selectedUpgrades[category] = colorOptions
            else

                selectedUpgrades[category] = { value = options[math.random(#options)] }
            end

            selectedUpgrades[category].item = item

        else
            --print("Error: Category not found in availableCategories -", category)
        end
    end

    -- Debug: Final selected upgrades with proper display
    --print("Final selected upgrades:")
    for cat, upgrade in pairs(selectedUpgrades) do
        local upgradeStr = ""
        if type(upgrade) == "table" then
            for k, v in pairs(upgrade) do
                if type(v) == "table" then
                    upgradeStr = upgradeStr .. k .. ": { r = " .. v.r .. ", g = " .. v.g .. ", b = " .. v.b .. " }, "
                else
                    upgradeStr = upgradeStr .. k .. ": " .. tostring(v) .. ", "
                end
            end
        else
            upgradeStr = tostring(upgrade)
        end
        --print(cat, ":", selectedUpgrades[cat].item, " - ", upgradeStr)
    end

    return selectedUpgrades
end

local function getRandomElement(table)
    return table[math.random(#table)]
end

RegisterNetEvent('pyh-mosleyjob:sv:giveUpgradeItems')
AddEventHandler('pyh-mosleyjob:sv:giveUpgradeItems', function(grpId)
    local src = source
    local player = GetPlayer(src)

    local upgrades = getRandomUpgrades()
    local upgradeCount = 0
    for category, upgrade in pairs(upgrades) do
        local item = upgrade.item
        ItemManager(item, 1, "add", player)
        upgradeCount = upgradeCount + 1
    end
    exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-mosleyjob:cl:getUpgrades", {upgrades}) 
    TriggerEvent("pyh-mosleyjob:sv:updateStatus", grpId, 0, upgradeCount, nil)
end)

RegisterNetEvent('pyh-mosleyjob:sv:initt')
AddEventHandler('pyh-mosleyjob:sv:initt', function(grpId)
    local src = source

    local selectedJob = getRandomElement(Config.jobs)  
    local vehModel = getRandomElement(Config.jobVehicles)
    local wait = math.random(6000, 15000)

    exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-mosleyjob:cl:startJob", {vehModel, selectedJob.ped, selectedJob.veh, wait}) 
end)

RegisterNetEvent('pyh-mosleyjob:sv:bridge')
AddEventHandler('pyh-mosleyjob:sv:bridge', function(grpId)
    local src = source

    exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-mosleyjob:cl:bridge", {}) 
end)

RegisterNetEvent('pyh-mosleyjob:sv:antibich')
AddEventHandler('pyh-mosleyjob:sv:antibich', function(grpId)
    local src = source
    local Player = GetPlayer(src)
    local calculatedPay = Config.payment
    if Config.Framework == 'QBCore'then
        Player.Functions.AddMoney("cash", calculatedPay, "mosleyCash")
    else
        Player.addAccountMoney("money", calculatedPay)
    end

    TriggerEvent("pyh-contacts:modifyRepS", source, "Mosley's", Config.gainRep)

    Notify(src, "You got paid $"..calculatedPay, "success")

    exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-mosleyjob:clear", {}) 
end)


RegisterNetEvent("pyh-mosleyjob:sv:assignDV", function(netId, grpId, interactId)
    exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-mosleyjob:cl:assignDV", {netId, interactId}) 
end)


RegisterNetEvent("pyh-mosleyjob:sv:updateStatus", function(grpId, installed, total, item)

    if item then
        ItemManager(item, 1, "remove", GetPlayer(source))
    end

    if installed < total then
        exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-mosleyjob:cl:updateStatus", {installed, total})
    else
        exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-mosleyjob:cl:returnVeh", {installed, total})   
    end
end)


for category, data in pairs(Config.UpgradeCategories) do
    if Config.Framework == 'QBCore' then
        pyh.Functions.CreateUseableItem(data.item, function(source)
            TriggerClientEvent('pyh-mosleyjob:upgradeVehicle', source, data.item)
            --ItemManager(data.item, 1, "remove", GetPlayer(source))
        end)
     else
        pyh.RegisterUsableItem(data.item, function(source)
            TriggerClientEvent('pyh-mosleyjob:upgradeVehicle', source, data.item)
            --ItemManager(data.item, 1, "remove", GetPlayer(source))
        end)
     end
end



--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


