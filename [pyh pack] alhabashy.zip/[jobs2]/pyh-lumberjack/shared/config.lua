--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/


-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


Config = {
    Framework = "QBCore",
    FrameworkFolder = "qb-core",
    Inventory = 'ox_inventory',

    treeModel = "prop_tree_cedar_02",

    logPerChop = 2,
    planksPerLog = 5,

    VehCoords = vector4(-574.3195, 5368.6880, 69.7720, 248.2354),

    woodPrice = 150,

    getClean = vector3(-552.43, 5369.49, 70.95),
    getCleaned = vector3(-574.66, 5311.73, 70.15),
    getPlanks = vector3(-510.31, 5278.65, 80.51),
    sand = vector3(-487.63, 5285.98, 80.51),
    finish = vector3(-28.13, -2659.9, 5.01),

    trees = {
        {coords = vector3(-533.0241, 5232.419, 78.04932), isFallen = false, netId = nil},
        {coords = vector3(-533.0241, 5232.419, 78.04932), isFallen = false, netId = nil},
        {coords = vector3(-533.0241, 5232.419, 78.04932), isFallen = false, netId = nil},
        {coords = vector3(-549.7684, 5225.637, 74.40001), isFallen = false, netId = nil},
        {coords = vector3(-610.4636, 5243.29, 70.89495), isFallen = false, netId = nil},
        {coords = vector3(-626.639, 5235.579, 73.53409), isFallen = false, netId = nil},
        {coords = vector3(-615.1752, 5191.193, 90.5518), isFallen = false, netId = nil},
        {coords = vector3(-563.9933, 5175.367, 97.60523), isFallen = false, netId = nil},
        {coords = vector3(-554.9098, 5181.466, 95.6798), isFallen = false, netId = nil},
        {coords = vector3(-572.5436, 5147.082, 105.5383), isFallen = false, netId = nil},
        {coords = vector3(-621.5879, 5147.348, 109.7678), isFallen = false, netId = nil},
        {coords = vector3(-647.5836, 5149.276, 114.0346), isFallen = false, netId = nil},
        {coords = vector3(-676.9713, 5183.662, 104.6053), isFallen = false, netId = nil},
        {coords = vector3(-679.4445, 5170.439, 107.2553), isFallen = false, netId = nil},
        {coords = vector3(-693.2548, 5198.487, 101.336), isFallen = false, netId = nil},
        {coords = vector3(-681.7182, 5217.234, 94.31977), isFallen = false, netId = nil},
        {coords = vector3(-731.4064, 5236.307, 96.71639), isFallen = false, netId = nil},
        {coords = vector3(-750.4053, 5235.176, 96.74647), isFallen = false, netId = nil},
        {coords = vector3(-783.0895, 5244.052, 96.96616), isFallen = false, netId = nil},
        {coords = vector3(-794.345, 5220.743, 104.3835), isFallen = false, netId = nil},
        {coords = vector3(-774.9187, 5201.017, 112.8307), isFallen = false, netId = nil},
        {coords = vector3(-785.6127, 5179.307, 123.9017), isFallen = false, netId = nil},
        {coords = vector3(-796.5718, 5172.778, 129.9497), isFallen = false, netId = nil},
        {coords = vector3(-780.9235, 5148.588, 130.8081), isFallen = false, netId = nil},
        {coords = vector3(-745.1706, 5137.747, 127.2476), isFallen = false, netId = nil},
        {coords = vector3(-731.2798, 5139.263, 119.5841), isFallen = false, netId = nil},
        {coords = vector3(-708.4751, 5137.168, 118.5429), isFallen = false, netId = nil},
        {coords = vector3(-705.2882, 5152.396, 114.5372), isFallen = false, netId = nil},
        {coords = vector3(-688.0153, 5109.744, 133.9302), isFallen = false, netId = nil},
        {coords = vector3(-669.6415, 5115.88, 129.4151), isFallen = false, netId = nil},
        {coords = vector3(-647.628, 5102.918, 129.7841), isFallen = false, netId = nil},
        {coords = vector3(-623.2059, 5106.835, 126.1773), isFallen = false, netId = nil},
        {coords = vector3(-610.7714, 5139.828, 112.4355), isFallen = false, netId = nil},
        {coords = vector3(-572.6792, 5114.756, 116.4724), isFallen = false, netId = nil},
        {coords = vector3(-567.9504, 5115.231, 115.271), isFallen = false, netId = nil},
        {coords = vector3(-545.4021, 5107.964, 113.2), isFallen = false, netId = nil},
        {coords = vector3(-537.0339, 5101.939, 114.3623), isFallen = false, netId = nil},
        {coords = vector3(-526.108, 5109.058, 110.3067), isFallen = false, netId = nil},
        {coords = vector3(-536.6732, 5048.677, 128.2262), isFallen = false, netId = nil},
        {coords = vector3(-509.8519, 5036.591, 139.1917), isFallen = false, netId = nil},
        {coords = vector3(-504.2481, 5061.736, 133.4578), isFallen = false, netId = nil},
        {coords = vector3(-486.1361, 5095.387, 120.5811), isFallen = false, netId = nil},
        {coords = vector3(-470.425, 5114.061, 118.298), isFallen = false, netId = nil},
        {coords = vector3(-443.7121, 5093.829, 133.3646), isFallen = false, netId = nil},
        {coords = vector3(-457.2676, 5076.589, 135.2982), isFallen = false, netId = nil},
        {coords = vector3(-418.4106, 5101.798, 134.6462), isFallen = false, netId = nil},
        {coords = vector3(-403.0612, 5136.409, 118.9606), isFallen = false, netId = nil},
        {coords = vector3(-456.6845, 5145.28, 105.613), isFallen = false, netId = nil},
        {coords = vector3(-470.6184, 5175.244, 95.43956), isFallen = false, netId = nil},
        {coords = vector3(-447.1844, 5184.225, 108.3261), isFallen = false, netId = nil},
        {coords = vector3(-412.8944, 5212.855, 126.5873), isFallen = false, netId = nil},
        {coords = vector3(-432.6586, 5234.703, 120.3319), isFallen = false, netId = nil},
        {coords = vector3(-412.2403, 5271.647, 125), isFallen = false, netId = nil},
        {coords = vector3(-404.919, 5297.353, 119.9205), isFallen = false, netId = nil},
        {coords = vector3(-381.5384, 5283.79, 130.708), isFallen = false, netId = nil},
        {coords = vector3(-349.9629, 5265.521, 154.6059), isFallen = false, netId = nil},
        {coords = vector3(-308.1098, 5278.954, 172.0645), isFallen = false, netId = nil},
        {coords = vector3(-308.1098, 5278.954, 172.0645), isFallen = false, netId = nil},
        {coords = vector3(-304.5515, 5317.642, 168.4377), isFallen = false, netId = nil},
        {coords = vector3(-297.899, 5319.049, 173.0546), isFallen = false, netId = nil},
        {coords = vector3(-316.688, 5322.041, 163.8272), isFallen = false, netId = nil},
        {coords = vector3(-347.0544, 5306.545, 138.2504), isFallen = false, netId = nil},
        {coords = vector3(-354.5252, 5342.961, 130.9863), isFallen = false, netId = nil},
        {coords = vector3(-371.0732, 5374.465, 120.6033), isFallen = false, netId = nil},
        {coords = vector3(-396.7314, 5364.5, 111.3137), isFallen = false, netId = nil},
        {coords = vector3(-410.5267, 5361.409, 108.1724), isFallen = false, netId = nil},
        {coords = vector3(-384.0824, 5413.675, 102.7409), isFallen = false, netId = nil},
        {coords = vector3(-412.1893, 5463.725, 87.69926), isFallen = false, netId = nil},
        {coords = vector3(-368.9183, 5489.154, 132.5008), isFallen = false, netId = nil},
        {coords = vector3(-345.2885, 5522.195, 158.2336), isFallen = false, netId = nil},
        {coords = vector3(-342.1321, 5501.601, 155.6988), isFallen = false, netId = nil},
        {coords = vector3(-309.2679, 5530.449, 178.2264), isFallen = false, netId = nil},
        {coords = vector3(-269.3416, 5529.913, 191.2529), isFallen = false, netId = nil},
        {coords = vector3(-243.5156, 5521.208, 209.663), isFallen = false, netId = nil},
        {coords = vector3(-207.5652, 5478.047, 184.0802), isFallen = false, netId = nil},
        {coords = vector3(-208.4907, 5394.685, 234.6538), isFallen = false, netId = nil},
        {coords = vector3(-490.8322, 5389.251, 76.62089), isFallen = false, netId = nil},
        {coords = vector3(-462.9597, 5396.421, 78.30272), isFallen = false, netId = nil},
        {coords = vector3(-448.1007, 5403.104, 78.33337), isFallen = false, netId = nil},
        {coords = vector3(-511.3619, 5400.315, 73.96419), isFallen = false, netId = nil},
        {coords = vector3(-512.3774, 5368.907, 72.80805), isFallen = false, netId = nil},
        {coords = vector3(-532.9822, 5401.164, 70.08067), isFallen = false, netId = nil},
        {coords = vector3(-526.0685, 5454.6, 71.50775), isFallen = false, netId = nil},
        {coords = vector3(-534.3738, 5449.306, 69.14627), isFallen = false, netId = nil},
        {coords = vector3(-516.1088, 5449.89, 74.07529), isFallen = false, netId = nil},
        {coords = vector3(-483.8195, 5485.604, 82.12525), isFallen = false, netId = nil},
        {coords = vector3(-464.357, 5477.582, 83.20703), isFallen = false, netId = nil},
        {coords = vector3(-491.9727, 5521.198, 75.63767), isFallen = false, netId = nil},
        {coords = vector3(-515.6085, 5494.653, 70.47828), isFallen = false, netId = nil},
        {coords = vector3(-536.3734, 5558.658, 60.29284), isFallen = false, netId = nil},
        {coords = vector3(-508.5266, 5608.792, 63.30936), isFallen = false, netId = nil},
        {coords = vector3(-477.8803, 5620.608, 64.17537), isFallen = false, netId = nil},
        {coords = vector3(-533.6964, 5638.166, 49.67779), isFallen = false, netId = nil},
        {coords = vector3(-482.2548, 5666.482, 58.35204), isFallen = false, netId = nil},
        {coords = vector3(-469.641, 5719.019, 68.04617), isFallen = false, netId = nil},
        {coords = vector3(-574.984, 5598.165, 42.41106), isFallen = false, netId = nil},
        {coords = vector3(-588.9465, 5559.654, 47.05266), isFallen = false, netId = nil},
        {coords = vector3(-606.2779, 5536.606, 46.64916), isFallen = false, netId = nil},
        {coords = vector3(-615.9483, 5540.977, 44.46906), isFallen = false, netId = nil},
        {coords = vector3(-619.5182, 5477.081, 52.00388), isFallen = false, netId = nil},
        {coords = vector3(-655.1204, 5472.9, 50.95716), isFallen = false, netId = nil},
        {coords = vector3(-688.3453, 5455.582, 45.78496), isFallen = false, netId = nil},
        {coords = vector3(-647.1627, 5429.278, 48.64663), isFallen = false, netId = nil},
        {coords = vector3(-619.8032, 5400.228, 49.49516), isFallen = false, netId = nil},
        {coords = vector3(-622.7793, 5386.264, 54.69902), isFallen = false, netId = nil},
        {coords = vector3(-633.5029, 5351.566, 50.90854), isFallen = false, netId = nil},
        {coords = vector3(-688.6064, 5381.031, 57.1683), isFallen = false, netId = nil},
        {coords = vector3(-730.3554, 5375.367, 57.03505), isFallen = false, netId = nil},
        {coords = vector3(-744.6347, 5354.532, 59.96453), isFallen = false, netId = nil},
        {coords = vector3(-719.3491, 5351.012, 63.97101), isFallen = false, netId = nil},
        {coords = vector3(-768.8539, 5353.266, 56.62178), isFallen = false, netId = nil},
        {coords = vector3(-825.0564, 5350.398, 59.96478), isFallen = false, netId = nil},
        {coords = vector3(-823.3613, 5332.935, 73.22174), isFallen = false, netId = nil},
        {coords = vector3(-889.9935, 5343.919, 58.86121), isFallen = false, netId = nil},
        {coords = vector3(-889.9935, 5343.919, 58.86121), isFallen = false, netId = nil},
        {coords = vector3(-943.5627, 5340.028, 64.31651), isFallen = false, netId = nil},
        {coords = vector3(-941.5255, 5323.889, 67.70086), isFallen = false, netId = nil},
        {coords = vector3(-952.0927, 5284.85, 79.51371), isFallen = false, netId = nil},
        {coords = vector3(-960.4422, 5222.798, 108.5485), isFallen = false, netId = nil},
        {coords = vector3(-967.7835, 5221.931, 109.2087), isFallen = false, netId = nil},
        {coords = vector3(-870.1626, 5213.991, 106.0396), isFallen = false, netId = nil},
        {coords = vector3(-845.5635, 5204.076, 109.1253), isFallen = false, netId = nil},
        {coords = vector3(-875.2475, 5157.877, 149.3262), isFallen = false, netId = nil},
        {coords = vector3(-908.3567, 5134.491, 158.7684), isFallen = false, netId = nil},
        {coords = vector3(-920.1871, 5087.569, 164.6645), isFallen = false, netId = nil},
        {coords = vector3(-910.0422, 5090.281, 162.0914), isFallen = false, netId = nil},
        {coords = vector3(-939.2368, 5021.184, 174.6281), isFallen = false, netId = nil},
        {coords = vector3(-785.1966, 4969.766, 208.5401), isFallen = false, netId = nil},
        {coords = vector3(-704.1971, 4980.379, 179.9412), isFallen = false, netId = nil},
        {coords = vector3(-654.7186, 4926.789, 179.2639), isFallen = false, netId = nil},
        {coords = vector3(-563.7581, 4950.407, 156.2035), isFallen = false, netId = nil},
        {coords = vector3(-544.3616, 4936.243, 154.8953), isFallen = false, netId = nil},
        {coords = vector3(-583.6925, 4922.442, 170.6332), isFallen = false, netId = nil}
    },



}
