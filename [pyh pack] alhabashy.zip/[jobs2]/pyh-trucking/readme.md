# NPC Contact
```lua
{
    name = "Frank Miller",
    text = "Hey there, I don't think we've crossed paths before. I'm Frank and i'm in charge of the Trucking company. You thinkin' about joining our crew, or are you just here to keep an eye on your progress as a truck specialist?",
    domain = "Trucking",
    ped = "s_m_m_postal_01",
    scenario = "WORLD_HUMAN_CLIPBOARD",
    police = true,
    coords = vector4(1185.3397, -3256.7158, 5.0288, 359.5007),
    options = {
        {
            label = "I want to work",
            requiredrep = 0,
            type = "add",
            event = "",
            data = {
                text = "Hey, all set for a day of hard work?",
                options = {
                    {
                        label = "Sign In",
                        requiredrep = 0,
                        event = "pyh-trucking:Sign",
                        type = "client",
                        args = {} 
                    },
                    {
                        label = "Leave conversation",
                        event = "",
                        type = "none",
                        args = {} 
                    },
                    
                }
            },
            args = {} 
            
        },
        {
            label = "Leave conversation",
            requiredrep = 0,
            type = "none",
            args = {} 
        },
        
    }
},
{
    name = "Harry Miller",
    
    text = "Hello, here you can check the stock.",
    domain = "Trucking",
    ped = "s_m_m_postal_01",
    scenario = "WORLD_HUMAN_CLIPBOARD",
    police = true,
    coords = vector4(56.5682, 122.6095, 78.1846, 251.0128),
    hide = true, --Keep this ped hidden from the tablet
    options = {
        {
            label = "Open Stock",
            requiredrep = 0,
            event = "pyh-trucking:openStock",
            type = "client",
            args = {} 
        },
        {
            label = "Complete Job",
            requiredrep = 0,
            type = "client",
            event = "pyh-trucking:AskCompleteDelivery",
            args = {} 
        },
        {
            label = "Leave conversation",
            requiredrep = 0,
            type = "none",
            args = {} 
        },
        
    }
},
```

# Item

```lua
grimebox = { name = 'grimebox', label = 'Grime Box', weight = 5000, type = 'item', image = 'np_box.png', unique = true, useable = true, shouldClose = true, combinable = nil, description = 'Box filled with cargo' },
```

# Add this change in the server side script if you're using a qb-inventory or an edit of it!   !!! VERY IMPORANT !!!

```lua
local function SaveStashItems(stashId, items)
	if (Stashes[stashId] and Stashes[stashId].label == "Stash-None") or not items then return end

	for _, item in pairs(items) do
		item.description = nil
	end

	MySQL.insert('INSERT INTO stashitems (stash, items) VALUES (:stash, :items) ON DUPLICATE KEY UPDATE items = :items', {
		['stash'] = stashId,
		['items'] = json.encode(items)
	})

	if Stashes[stashId] then
		Stashes[stashId].isOpen = false
	end
end

RegisterNetEvent('inventory:server:SetStashItems', function(stashId, items)
	SaveStashItems(stashId, items)
end)

````