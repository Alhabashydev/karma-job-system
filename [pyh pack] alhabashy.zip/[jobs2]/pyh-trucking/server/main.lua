--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


function shuffleTable(t)
    local rand = math.random 
    assert(t, "shuffleTable() expected a table, got nil")
    local iterations = #t
    local j

    for i = iterations, 2, -1 do
        j = rand(1, i)
        t[i], t[j] = t[j], t[i]
    end
end

function assignStops(contract)
    local boxesPerStopMax = 6
    local minBoxesPerStop = 1
    local totalBoxes = math.ceil(contract.weight / 50)
    local numStops = math.random(2, math.min(#Config.Pickups[contract.index], math.ceil(totalBoxes / minBoxesPerStop)))

    numStops = math.max(numStops, 1)
    
    --print("Total Boxes: " .. totalBoxes)
    --print("Number of Stops: " .. numStops)

    -- Shuffle
    local stops = Config.Pickups[contract.index]
    shuffleTable(stops)

    local stopAssignments = {}
    local remainingBoxes = totalBoxes
    for i = 1, numStops do
        stopAssignments[i] = minBoxesPerStop
        remainingBoxes = remainingBoxes - minBoxesPerStop
    end

    local i = 1
    while remainingBoxes > 0 do
        if stopAssignments[i] < boxesPerStopMax then
            local addBoxes = math.min(boxesPerStopMax - stopAssignments[i], remainingBoxes)
            stopAssignments[i] = stopAssignments[i] + addBoxes
            remainingBoxes = remainingBoxes - addBoxes
        end
        i = (i % numStops) + 1
    end

    -- Print debug info
--[[     print("Stop Assignments:")
    for i = 1, numStops do
        print(string.format("Stop %d: %d boxes", i, stopAssignments[i]))
    end ]]

    local assignedStops = {}
    for i = 1, numStops do
        local randomName = "trpk" .. i .. math.random(100, 999)
        table.insert(assignedStops, { stop = stops[i], boxes = stopAssignments[i], name = randomName })
    end

    return assignedStops
end

--[[ RegisterCommand("testjob", function(source, args, rawCommand)
    local contractIndex = tonumber(args[1])

    if contractIndex and Config.Contracts[contractIndex] then
        local contract = Config.Contracts[contractIndex]
        local stops = assignStops(contract)

        -- Print out the stops and their assigned boxes
        for i, stop in ipairs(stops) do
            print(string.format("Stop %d: Location: (%.4f, %.4f, %.4f, %.4f), Boxes: %d", 
                i, stop.stop.x, stop.stop.y, stop.stop.z, stop.stop.w, stop.boxes))
        end

        -- Notify the player
        TriggerClientEvent('chat:addMessage', source, {
            args = { 'Job System', string.format('You have started a job: %s', contract.name) }
        })
        
        for i, stop in ipairs(stops) do
            TriggerClientEvent('chat:addMessage', source, {
                args = { 'Job System', string.format('Stop %d: Location: (%.4f, %.4f, %.4f, %.4f), Boxes: %d', 
                i, stop.stop.x, stop.stop.y, stop.stop.z, stop.stop.w, stop.boxes) }
            })
        end
    else
        TriggerClientEvent('chat:addMessage', source, {
            args = { 'Job System', 'Invalid contract index!' }
        })
    end
end, false) ]]




RegisterNetEvent('pyh-trucking:StartGrp')
AddEventHandler('pyh-trucking:StartGrp', function(index, grpId, vehNet)
    local src = source

    local pickupsLocations = Config.Pickups[index]

    if index and Config.Contracts[index] then
        local contract = Config.Contracts[index]
        local stops = assignStops(contract)

        local hubId = "HUB"..grpId..math.random(100, 999)

        for i, stop in ipairs(stops) do
            local stopName = stop.name
            local numberOfBoxes = stop.boxes
            
            local itms = {}

            for i = 1, numberOfBoxes do
                table.insert(itms, {
                    slot = i,
                    name = Config.boxItem,
                    amount = 1,
                    info = {},
                    type = 'item'
                })
                
            end               
            
            local StashName = stopName
            TriggerEvent('pyh-trucking:sv:SetStashItems', StashName, itms)    

        end
        TriggerEvent('pyh-trucking:sv:SetStashItems', hubId, {})

        exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-trucking:StartActualWork", {index, stops, hubId, vehNet}) 
    end
end)

RegisterNetEvent("pyh-trucking:sv:AskCompleteDelivery", function(grpId, hubId)

    TriggerEvent('pyh-trucking:sv:SetStashItems', hubId, {})
    exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-trucking:CompleteDelivery", {}) 
end)


RegisterNetEvent("pyh-trucking:sv:CompleteDelivery", function(grpId, dist, currentIndex)
    local src = source

    local p = Config.Contracts[currentIndex].payment
    local gainRep = Config.Contracts[currentIndex].gainRep
    local calculatedPay = math.random(p[1], p[2])

    if dist <= 30 then

        if Config.Framework == 'QBCore'then
            local Player = pyh.Functions.GetPlayer(src)
            Player.Functions.AddMoney("cash", calculatedPay, "trucking-pay")
        else
            local xPlayer = pyh.GetPlayerFromId(src)
            xPlayer.addAccountMoney("money", calculatedPay)
        end
        
        TriggerEvent("pyh-contacts:modifyRepS", src, "Trucking", 1)
        
        Notify(src, "You got paid "..calculatedPay.." for this job!", "success")
        
        exports["pyh-groupsystem"]:GroupEvent(grpId, "pyh-trucking:Clear", {}) 
    else
        --possible exploit situation
    end  
end)



RegisterNetEvent("pyh-trucking:sv:getBoxes", function(data)
    local src = source

    local name=data[1] 
    local amount=data[2] 
    local gropId=data[3]

    TriggerClientEvent("pyh-trucking:OpenST", src, name)

    exports["pyh-groupsystem"]:GroupEvent(gropId, "pyh-trucking:RemovePickup", {name, amount}) 
end)


RegisterNetEvent("pyh-trucking:sv:SetStashItems", function(StashName, itms)
    local src = source
    
    if Config.Inventory == "qb-inventory" then
        TriggerEvent('inventory:server:SetStashItems', StashName, itms)
    elseif Config.Inventory == "ox_inventory" then

        local inventory = exports.ox_inventory:GetInventory(StashName, false)
        if inventory == nil or inventory == false then
            exports.ox_inventory:RegisterStash(StashName, StashName, 20, 3300000)
        end
        if isTableEmpty(itms) then

            exports.ox_inventory:ClearInventory(StashName, false)
        else
            for _, item in ipairs(itms) do
                local uniqueId = tostring(math.random(100000, 999999))

                exports.ox_inventory:AddItem(StashName, item.name, item.amount, {uniqueId = uniqueId})
            end
        end
    end
end)

RegisterNetEvent("pyh-trucking:sv:OpenInventory", function(storageId, weight, slots)
    local src = source
    if Config.Inventory == "qb-inventory" then
        weight = weight or 3300000
        slots = slots or 40
        if storageId then
            TriggerClientEvent("inventory:client:SetCurrentStash", src, storageId)
            Wait(0)
            TriggerEvent("inventory:server:OpenInventory", "stash", storageId, {
                maxweight = weight,
                slots = slots,
            })
        else
        end
    elseif Config.Inventory == "ox_inventory" then
        local weight = weight or 3300000
        local slots = slots or 40
        local inventory = exports.ox_inventory:GetInventory(storageId, false)
        print(json.encode(inventory, { indent = true }))
        if inventory == nil or inventory == false then
            exports.ox_inventory:RegisterStash(storageId, storageId, slots, weight)
        end
        exports.ox_inventory:forceOpenInventory(src, 'stash', storageId)
    end
end)--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


