--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


local currentJobStage = "WAITING"
local GroupID = 0
local isGroupLeader = false

local hasJob = false
local vehicleNet = nil
local askForVeh = false
local totalPicked = 0
local totalPickups = 0

local currentIndex = nil

local lastDeleted = nil

local createdNPCs = {}
local blips = {}

local hubId = nil

function deleteAllNPCs()
    if createdNPCs then
        for _, npcPed in ipairs(createdNPCs) do
            if DoesEntityExist(npcPed) then
                DeletePed(npcPed)
            end
        end
        createdNPCs = {}
    end
end

RegisterNUICallback("hideMenu", function()
    SetNuiFocus(false, false)
    TriggerEvent("pyh-tablet:fB2")
end)

RegisterNetEvent("pyh-trucking:OpenTab", function()
    
    if GroupID == 0 then
        TriggerEvent("pyh-tablet:fB2")
        Notify("Make a group first!", "error")
        return
    end
   
    local cR = Rep() or 0

    SendNUIMessage({
        type = "open",
        rep = cR,
        contracts = Config.Contracts
    })
    SetNuiFocus(true, true)
    
end)

local function SpawnVeh(index)
    local spawnPoint = Config.VehicleSpawn
    local m = Config.Contracts[index].vehicle
    exports["pyh-interaction"]:hideInteraction()
    if Config.Framework == 'QBCore' then
        pyh.Functions.SpawnVehicle(m, function(veh)  
            SetEntityHeading(veh, spawnPoint.w)
            SetVehicleEngineOn(veh, false, false)
            SetVehicleOnGroundProperly(veh)
            SetVehicleNeedsToBeHotwired(veh, false)
              
            TriggerEvent("vehiclekeys:client:SetOwner", GetVehicleNumberPlateText(veh))
            SetVehicleDoorsLocked(veh, 1)

            vehicleNet = NetworkGetNetworkIdFromEntity(veh)
            
            askForVeh = false
            TriggerServerEvent("pyh-trucking:StartGrp", index, GroupID, vehicleNet)

            
            if m == 'Packer' then
                local containerModel = 'trailers2'
        
                -- Load the container model
                RequestModel(containerModel)
                while not HasModelLoaded(containerModel) do
                    Wait(0)
                end
                
                -- Spawn the container and attach it to the packer
                local container = CreateVehicle(GetHashKey(containerModel), spawnPoint.x, spawnPoint.y, spawnPoint.z, spawnPoint.w, true, true)
                AttachVehicleToTrailer(veh, container, 1.0)
            end

        end, spawnPoint, true)

    else
        pyh.Game.SpawnVehicle(m, spawnPoint, spawnPoint.w, function(veh)
            SetEntityHeading(veh, spawnPoint.w)
            SetVehicleEngineOn(veh, false, false)
            SetVehicleOnGroundProperly(veh)
            SetVehicleNeedsToBeHotwired(veh, false)          

            TriggerEvent("keys:received", GetVehicleNumberPlateText(veh))
            SetVehicleDoorsLocked(veh,1)

            vehicleNet = NetworkGetNetworkIdFromEntity(veh)
            askForVeh = false

            TriggerServerEvent("pyh-trucking:StartGrp", index, GroupID, vehicleNet)
        end)
    end
end

RegisterNUICallback("StartContract", function(data) 
    if hasJob then
        Notify("Finish your current job first!", "error")
        return
    end

    currentIndex = data.index

    if vehicleNet == nil or not DoesEntityExist(NetworkGetEntityFromNetworkId(vehicleNet)) then
        askForVeh = true

        exports["pyh-status"]:Show("Trucker", {"Go to the foreman"})

        local vehZone = BoxZone:Create(Config.VehicleZone, 5.0, 5.0, {
            name="truckingAskVeh",
            offset={0.0, 0.0, 0.0},
            scale={1.0, 1.0, 1.0},
            debugPoly=false,
        })

        vehZone:onPlayerInOut(function(inside)
            if inside then
                exports['pyh-interaction']:showInteraction("E", "Ask the foreman for a vehicle")
            else
                exports["pyh-interaction"]:hideInteraction()
            end
        end)

        CreateThread(function ()
            while askForVeh do
                Citizen.Wait(0)
                if IsControlJustReleased(0, 38) then 

                    local spawnPoint = Config.VehicleSpawn
                    if IsAnyVehicleNearPoint(spawnPoint.x, spawnPoint.y,spawnPoint.z, 2.0) then
                        Notify("Spawn point is occupied!", "error")
                    else
                        vehZone:destroy()
                        SpawnVeh(data.index)
                    end

                end
            end
        end)
    else
        if DoesEntityExist(NetworkGetEntityFromNetworkId(vehicleNet)) then
            local vehicleEntity = NetworkGetEntityFromNetworkId(vehicleNet)
            local vehicleHash = GetEntityModel(vehicleEntity)
            
            local modelHash = GetHashKey(Config.Contracts[data.index].vehicle)

            if vehicleHash == modelHash then
                askForVeh = false
                TriggerServerEvent("pyh-trucking:StartGrp", data.index, GroupID, vehicleNet)
            else
                vehicleNet = nil
                Notify("Please retake the contract!", "error")
            end
        end
    end
end)


RegisterNetEvent("pyh-trucking:StartActualWork", function(index, stops, hubI, vehNet)
    hasJob = true
    vehicleNet = vehNet
    hubId = hubI
    
    totalPickups = #stops
    totalPicked = 0

    exports["pyh-status"]:Show("Trucker", {"Check the locations on your GPS and load the cargo", totalPicked.."/"..totalPickups, })

    for i, stop in ipairs(stops) do
        local stopName = stop.name
        local location = stop.stop 
        local numberOfBoxes = stop.boxes

        local npcPed = CreatePed(4, GetHashKey('s_m_m_postal_01'), location.x, location.y, location.z, location.w, false, false)
        FreezeEntityPosition(npcPed, true)
        SetEntityInvincible(npcPed, true)
        SetBlockingOfNonTemporaryEvents(npcPed, true)

        TaskStartScenarioInPlace(npcPed, "WORLD_HUMAN_CLIPBOARD", 0, true)

        exports.interact:AddLocalEntityInteraction({
            entity = npcPed,
            id = stopName..math.random(100, 999), -- needed for removing interactions
            distance = 6.0, 
            interactDst = 4.0,
            ignoreLos = true, 
            options = {
                {
                    label = "Open Stock",
                    action = function(entity, coords, args)
                        TriggerServerEvent("pyh-trucking:sv:getBoxes", { stopName, numberOfBoxes, GroupID })
                    end,
                },
            }
        })

        local blip = AddBlipForCoord(location.x, location.y, location.z)
        SetBlipSprite(blip, 501) 
        SetBlipColour(blip, 17)
        SetBlipScale(blip, 0.8) 

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Pickup Location")
        EndTextCommandSetBlipName(blip)
        
        blips[stop.name] = blip

        table.insert(createdNPCs, npcPed)
    end
end)

RegisterNetEvent("pyh-trucking:RemovePickup", function(name, amnt)
    if lastDeleted ~= name then 
        lastDeleted = name

        totalPicked = totalPicked + 1
        
        local blip = blips[name]
        if blip then
            RemoveBlip(blip)
            blips[name] = nil
        end

        Wait(math.random(5000, 8000))
        exports["pyh-status"]:Show("Trucker", {"Check the locations on your GPS and load the cargo", totalPicked.."/"..totalPickups, })   

        if next(blips) == nil and totalPicked >= totalPickups then
            Wait(5000)
            exports["pyh-status"]:Show("Trucker", {"Head to the Hub to unload the cargo"})
            SetNewWaypoint(Config.CentralHub.x, Config.CentralHub.y)
        end
        
    end
end)

RegisterNetEvent("pyh-trucking:openStock", function()
    if Config.Inventory == "ox_inventory" then
        TriggerServerEvent("pyh-gruppe6job:sv:OpenInventory", hubId, 3300000, 40)
    else
        TriggerServerEvent("inventory:server:OpenInventory", "stash", hubId, {
            maxweight = 3300000,
            slots = 40,
        })
        TriggerEvent("inventory:client:SetCurrentStash", hubId) 
    end
end)

RegisterNetEvent("pyh-trucking:AskCompleteDelivery", function()
    if totalPicked >= totalPickups then
        TriggerServerEvent("pyh-trucking:sv:AskCompleteDelivery", GroupID, hubId)
    else
        Notify("You still got work to do!", "error")
    end
end)


RegisterNetEvent("pyh-trucking:CompleteDelivery", function()
    if totalPickups and GroupID and totalPicked > 1 then
        if totalPicked >= totalPickups then        
            local playerCoords = GetEntityCoords(PlayerPedId(-1))
            local dist = GetDistanceBetweenCoords(playerCoords, Config.CentralHub, false)

            TriggerServerEvent("pyh-trucking:sv:CompleteDelivery", GroupID, dist, currentIndex)
        end
    end 
end)

RegisterNetEvent("pyh-trucking:Clear", function()
    hasJob = false
    askForVeh = false
    totalPicked = 0
    totalPickups = 0
    currentIndex = nil
    lastDeleted = nil
    
    deleteAllNPCs()

    createdNPCs = {}
    blips = {}
    hubId = nil
    
    exports["pyh-status"]:Close()
end)

RegisterNetEvent("pyh-trucking:OpenST", function(name, amnt)
    amnt = amnt or 20

    if Config.Inventory == "ox_inventory" then
        TriggerServerEvent("pyh-trucking:sv:OpenInventory", name, 3300000, amnt)
    else  
        TriggerServerEvent('inventory:server:OpenInventory', 'stash', name, {
            maxweight = 3300000,
            slots = amnt,
        })
        TriggerEvent("inventory:client:SetCurrentStash", name)
    end
end)

--netl3uha ela bnadem chwia
local duty = false
RegisterNetEvent("pyh-trucking:Sign", function()
    duty = not duty
    if duty then
        Notify("You're now signed in!", "success")
    else
        Notify("You're now signed out!", "error")
    end
end)


CreateThread(function()
    while true do
        sleep = 1000
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)
            local v = Config.DeleteVeh

            local dist = #(pos - vector3(v.x, v.y, v.z))
            if dist < 40 then
                sleep = 0
                DrawMarker(39, v.x, v.y, v.z + 1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.0, 3.0, 3.0, 50, 50, 255, 222, false, false, false, true, false, false, false)
                if dist < 4 then
                    if IsControlJustReleased(0, 38) then
                        if IsPedInAnyVehicle(ped, false) then
                            local vehicle = GetVehiclePedIsIn(ped, false)
                            local model = GetEntityModel(vehicle)

                            if NetworkGetNetworkIdFromEntity(vehicle) == vehicleNet then
                                DeleteVehicle(vehicle)
                            else 
                                Notify("Do you think that I'm a fucking garage?", "error")
                            end
                        end
                    end
                end
            end  
        Wait(sleep)
    end
end)

--[[ Grp Events ]]

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        deleteAllNPCs()
    end
end)

RegisterNetEvent("groups:updateJobStage", function(stage)
    currentJobStage = stage

end)

RegisterNetEvent("groups:JoinGroup", function(id)
    GroupID = id
end)

RegisterNetEvent("groups:UpdateLeader", function()
    isGroupLeader = true
end)

RegisterNetEvent("groups:GroupDestroy", function()
    currentJobStage = "WAITING"
    GroupID = 0
    isGroupLeader = false
end)--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


