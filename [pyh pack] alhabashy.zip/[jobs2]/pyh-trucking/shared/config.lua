--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


Config = {
    Framework = "QBCore",
    FrameworkFolder = "qb-core",
    Inventory = 'qb-inventory',
    boxItem = "grimebox",
    Contracts = {
        { index = 1, requiredRep = 0, name="Los Santos (Clothing Shops)", weight = 200, payment = {1890, 3400}, vehicle = "Boxville2", cargo = "Clothes", gainRep = 18.7},
        { index = 2, requiredRep = 0, name="Los Santos (Robs Liquor)", weight = 200, payment = {2100, 4690}, vehicle = "Boxville2", cargo = "Drinks", gainRep = 20.8},
        { index = 3, requiredRep = 50, name="Highway (Convenience Stores)", weight = 300, payment = {5553, 7836}, vehicle = "Pounder", cargo = "Food", gainRep = 33.2},
        { index = 4, requiredRep = 50, name="Sandy Shores (24/7 Stores)", weight = 250, payment = {7480, 8253}, vehicle = "Pounder", cargo = "Drinks", gainRep = 33.5},
        { index = 5, requiredRep = 100, name="Highway (Convenience Stores)", weight = 900, payment = {8512, 9666}, vehicle = "Packer", cargo = "Drinks", gainRep = 45.5},
        { index = 6, requiredRep = 100, name="Gas Stations", weight = 600, payment = {15012, 16660}, vehicle = "Packer", cargo = "Electronics", gainRep = 45.5},

    },
    VehicleZone = vector4(1185.1698, -3254.5354, 6.0153, 179.6372), -- Press G to spawn DVeh
    VehicleSpawn = vector4(1173.9551, -3249.4954, 5.5918, 1.1805), -- Delivery veh spawn location
    DeleteVeh = vector3(1200.8978, -3241.2832, 5.9550),
    CentralHub = vector3(56.5396, 122.6207, 79.1841),

    Pickups = {
        --Clothing Stores
        { 
            vector4(-815.9044, -1078.3472, 10.1326, 210.5712),
            vector4(-1459.1284, -234.4684, 48.4702, 47.5850),
            vector4(-715.8545, -159.5994, 35.9880, 118.2847),
            vector4(-153.6044, -303.5464, 37.9219, 251.9088),
            vector4(126.3776, -207.7034, 53.5793, 335.1445),
            vector4(418.2746, -809.5288, 28.3561, 87.9020),
            vector4(82.9293, -1389.6385, 28.4199, 263.4030),
            vector4(-1202.0940, -781.7662, 16.3315, 93.5818),
        },
        {
            vector4(-1490.1743, -384.8809, 39.1015, 145.5757),
            vector4(1142.2496, -979.2807, 45.2786, 271.1852),
            vector4(-2974.1086, 389.2931, 14.0309, 82.0706),
            vector4(-1228.0454, -903.0594, 11.2276, 30.0343),
        },
        {
            vector4(2560.3391, 382.9067, 107.6212, 270.1992),
            vector4(2684.6340, 3284.4060, 54.2405, 236.7900),
            vector4(1733.5771, 6409.5586, 34.0007, 155.4620),
            vector4(-3239.2654, 1006.0173, 11.6122, 249.7512),
            vector4(-3038.8447, 591.4800, 6.9145, 282.1655),
        },
        {
            vector4(1966.6603, 3740.6467, 31.3427, 195.1530),
            vector4(2684.6340, 3284.4060, 54.2405, 236.7900), 
            vector4(546.3259, 2674.2122, 41.1625, 4.8611),
            vector4(1167.9122, 2702.9482, 37.1781, 172.7408)
        },
        {
            vector4(2560.3391, 382.9067, 107.6212, 270.1992),
            vector4(2684.6340, 3284.4060, 54.2405, 236.7900),
            vector4(1733.5771, 6409.5586, 34.0007, 155.4620),
            vector4(-3239.2654, 1006.0173, 11.6122, 249.7512),
            vector4(-3038.8447, 591.4800, 6.9145, 282.1655),
            vector4(-2974.2461, 389.3326, 14.0305, 84.2741)
        },
        {
            vector4(647.3812, 268.9473, 102.2624, 69.8583),
            vector4(1162.1547, -326.6700, 68.2222, 190.1701),
            vector4(288.8610, -1264.3228, 28.4408, 92.4671),
            vector4(-55.6134, -1755.7782, 28.4396, 138.2017),
            vector4(-342.5019, -1484.7802, 29.7173, 275.2601),
            vector4(-529.7386, -1222.0206, 17.4550, 338.5707),
            vector4(-709.4024, -917.0747, 18.2143, 176.6184),
            vector4(165.9439, 6627.3105, 30.7548, 154.0695),
            vector4(-2542.0774, 2317.1621, 32.2158, 10.6380),
            vector4(-1823.5233, 786.3622, 137.2166, 226.7469),
            vector4(1696.0629, 4928.7466, 41.0782, 50.4983),
        },
    },
}--[[

-------------------------------------------------------------------------------------------

  ___    ___    _  _   ___      _      ___     _     _  __  ___ 
 | _ )  / _ \  | \| | |   \    | |    | __|   /_\   | |/ / / __|
 | _ \ | (_) | | .` | | |) |   | |__  | _|   / _ \  | ' <  \__ \
 |___/  \___/  |_|\_| |___/    |____| |___| /_/ \_\ |_|\_\ |___/
                                                                 

-------------------------------------------------------------------------------------------
Password: BondLeaks

JOIN HERE IF YOU WANT MORE EXCLUSIVE FIVEM LEAKS
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK
https://discord.gg/CeF44BBPkK

OR OUR SITE

https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com
https://bond5m.com


]]--


